-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 19, 2026 at 12:23 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `indo_weather`
--

-- --------------------------------------------------------

--
-- Table structure for table `kategori`
--

CREATE TABLE `kategori` (
  `id` int(11) NOT NULL,
  `nama_kategori` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `kategori`
--

INSERT INTO `kategori` (`id`, `nama_kategori`) VALUES
(1, 'Sensor Cuaca'),
(2, 'Sensor Udara'),
(3, 'Data Logger'),
(4, 'Aksesoris'),
(5, 'Jasa');

-- --------------------------------------------------------

--
-- Table structure for table `konfigurasi`
--

CREATE TABLE `konfigurasi` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `tanggal` timestamp NOT NULL DEFAULT current_timestamp(),
  `total_harga` decimal(12,2) NOT NULL DEFAULT 0.00,
  `status` enum('inquiry','diproses','selesai','dibatalkan') NOT NULL DEFAULT 'inquiry'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `konfigurasi`
--

INSERT INTO `konfigurasi` (`id`, `user_id`, `tanggal`, `total_harga`, `status`) VALUES
(11, 5, '2026-07-17 04:28:04', 25200000.00, 'inquiry'),
(12, 5, '2026-07-17 06:03:38', 45700000.00, 'inquiry');

-- --------------------------------------------------------

--
-- Table structure for table `konfigurasi_detail`
--

CREATE TABLE `konfigurasi_detail` (
  `id` int(11) NOT NULL,
  `konfigurasi_id` int(11) NOT NULL,
  `produk_id` int(11) NOT NULL,
  `harga` decimal(12,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `konfigurasi_detail`
--

INSERT INTO `konfigurasi_detail` (`id`, `konfigurasi_id`, `produk_id`, `harga`) VALUES
(28, 11, 12, 7200000.00),
(29, 11, 2, 15500000.00),
(30, 11, 15, 2500000.00),
(31, 12, 4, 8900000.00),
(32, 12, 5, 9500000.00),
(33, 12, 6, 7600000.00),
(34, 12, 2, 15500000.00),
(35, 12, 16, 4200000.00);

-- --------------------------------------------------------

--
-- Table structure for table `produk`
--

CREATE TABLE `produk` (
  `id` int(11) NOT NULL,
  `kategori_id` int(11) NOT NULL,
  `kode_produk` varchar(30) NOT NULL,
  `nama_produk` varchar(150) NOT NULL,
  `harga` decimal(12,2) NOT NULL,
  `stok` int(11) NOT NULL DEFAULT 0,
  `gambar` varchar(255) DEFAULT NULL,
  `datasheet` varchar(255) DEFAULT NULL,
  `deskripsi` text DEFAULT NULL,
  `status` enum('aktif','nonaktif') DEFAULT 'aktif',
  `urutan` int(11) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `produk`
--

INSERT INTO `produk` (`id`, `kategori_id`, `kode_produk`, `nama_produk`, `harga`, `stok`, `gambar`, `datasheet`, `deskripsi`, `status`, `urutan`, `created_at`) VALUES
(2, 3, 'DLT-101', 'Data Logger', 15500000.00, 5, '1784189564_img.png', '1784189564_pdf.pdf', 'Low Power High Performance Data Logger Telemetry\r\n\r\nARM base Ultra-low power CPU with sleep mode,\r\nHigh end cooling system for stable performance,\r\nData logging 5 channel analog, 16 channel RS-485,\r\n4GB internal storage,\r\nAP mode mini web server data logging application,\r\nKoneksi GPRS/4G/LTE,\r\nWeb-based cloud monitoring,\r\nOptional third-party cloud integration,\r\nIP67 weatherproof,', 'aktif', 1, '2026-07-16 08:12:44'),
(3, 1, 'IWSC001', 'Sensor Angin (Kecepatan & Arah)', 8200000.00, 8, '1784189830_img.png', '1784189830_pdf.pdf', 'Sensor angin teknologi mutakhir, akurasi tinggi, bahan industrial ABS yang tahan terhadap cuaca hingga lebih dari 10 tahun.', 'aktif', 2, '2026-07-16 08:17:10'),
(4, 2, 'IWSU001', 'Sensor CO', 8900000.00, 5, '1784189985_img.png', '1784189985_pdf.pdf', 'Sensor Elektrokimia CO untuk mendeteksi karbon monoksida dengan akurasi tinggi dan response time cepat', 'aktif', 3, '2026-07-16 08:19:45'),
(5, 2, 'IWSU002', 'Sensor CO2', 9500000.00, 4, '1784190126_img.png', '1784190126_pdf.pdf', 'Sensor NDIR non-dispersive infrared untuk pengukuran karbondioksida dengan range hingga 5000ppm', 'aktif', 4, '2026-07-16 08:22:06'),
(6, 2, 'IWSU003', 'Sensor H2S', 7600000.00, 7, '1784190260_img.png', '1784190260_pdf.pdf', 'Sensor Elektrokimia H2S untuk mendeteksi Hidrogen Sulfida di udara pada industri kimia dan wastewater', 'aktif', 5, '2026-07-16 08:24:20'),
(7, 1, 'IWSC002', 'Sensor Curah Hujan', 6500000.00, 6, '1784190349_img.png', '1784190349_pdf.pdf', 'Sensor pernghitung laju curah hujan dengan ketelitian 0.2mm', 'aktif', 6, '2026-07-16 08:25:49'),
(8, 1, 'IWSC003', 'Sensor Level Air', 3800000.00, 9, '1784190522_img.png', '1784190522_pdf.pdf', 'Sensor ultrasonik non-contact akurasi tinggi untuk pengukuran level air sungai, waduk, dan tangki', 'aktif', 7, '2026-07-16 08:28:42'),
(9, 2, 'IWSU004', 'Sensor O2', 6800000.00, 4, '1784190651_img.png', '1784190651_pdf.pdf', 'Sensor elektrokimia oksigen untuk monitoring kada O2 di lingkungan industri, perkantoran, perkotaan maupun di dunia medis', 'aktif', 8, '2026-07-16 08:30:51'),
(11, 2, 'IWSU005', 'Sensor PM2.5 & PM10', 11200000.00, 7, '1784191106_img.png', '1784191106_pdf.pdf', 'Laser particle counter untuk pengukuran partikel halus PM2.5 dan PM10 secara simultan', 'aktif', 9, '2026-07-16 08:38:26'),
(12, 1, 'IWSC004', 'Sensor Solar Radiation', 7200000.00, 8, '1784191229_img.png', '1784191229_pdf.pdf', 'Pyranometer kelas 1 untuk pengukuran radiasi matahari global dengan akurasi tinggi', 'aktif', 10, '2026-07-16 08:40:29'),
(13, 2, 'IWSU006', 'Sensor Udara (Suhu, RH, Tekanan)', 4500000.00, 11, '1784191365_img.png', '1784191365_pdf.pdf', 'Sensor digital multifungsi dengan akurasi tinggi untuk Suhu, Kelembabanm dan Tekanan Udara', 'aktif', 11, '2026-07-16 08:42:45'),
(14, 4, 'IWSA001', 'Paket Solar Power System', 2700000.00, 5, '1784191512_img.png', '1784191512_pdf.pdf', 'Sistem solar power lengkap 30W dengan battery backup untuk operasi off-grid', 'aktif', 12, '2026-07-16 08:45:12'),
(15, 4, 'IWSA002', 'Tripod 3 Meter', 2500000.00, 3, '1784191652_img.png', '1784191652_pdf.pdf', 'Tripod stailess steel 3 meter dengan anchor ground untuk stabilitas tinggi', 'aktif', 13, '2026-07-16 08:47:32'),
(16, 4, 'IWSA003', 'Monopole 4 Meter', 4200000.00, 2, '1784191846_img.png', '1784191846_pdf.pdf', 'Monopole galvanis 4 meter untuk instalasi permanen di lokasi terpencil', 'aktif', 14, '2026-07-16 08:50:46'),
(18, 5, 'IWSJ001', 'Jasa Instalasi Basic', 7500000.00, 999, '1784362912_img.png', '1784362912_pdf.pdf', 'Instalasi:\r\n1. Sensor – sensor dari IndoWeatherSensor\r\n2. Data Logger Telemetri dari IndoWeatherSensor\r\n3. Solar Power System\r\n4. Tripod/monopole standard dari IndoWeatherSensor\r\n5. Setup dan Training Pengoperasian ', 'aktif', 15, '2026-07-18 08:21:52'),
(19, 5, 'IWSJ002', 'Jasa Instalasi Standard', 12000000.00, 999, '1784363515_img.png', '1784363515_pdf.pdf', 'Instalasi:\r\n1. Sensor – sensor dari IndoWeatherSensor\r\n2. Data Logger Telemetri dari IndoWeatherSensor\r\n3. Solar Power System\r\n4. Tripod/monopole standard dari IndoWeatherSensor\r\n5. Setup dan Training Pengoperasian \r\n6. Garansi instalasi 1 tahun', 'aktif', 16, '2026-07-18 08:31:55'),
(20, 5, 'IWSJ003', 'Jasa Instalasi Premium', 18500000.00, 999, '1784363664_img.png', '1784363664_pdf.pdf', 'Instalasi:\r\n1. Sensor – sensor dari IndoWeatherSensor\r\n2. Data Logger Telemetri dari IndoWeatherSensor\r\n3. Solar Power System\r\n4. Tripod/monopole standard dari IndoWeatherSensor\r\n5. Setup dan Training Pengoperasian \r\n6. Garansi instalasi 1 tahun* \r\n7. Remote monitoring 1 tahun \r\n8. Maintenance 1 tahun ', 'aktif', 17, '2026-07-18 08:34:24');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `no_hp` varchar(20) NOT NULL,
  `alamat` text DEFAULT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('admin','user') NOT NULL DEFAULT 'user',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `nama`, `email`, `no_hp`, `alamat`, `username`, `password`, `role`, `created_at`) VALUES
(3, 'Administrator', 'admin@adamb25.my.id', '081122223333', 'Jl. Merdeka No. 123, Jakarta, Indonesia', 'admin', '$2y$10$jzOfuaahMACQRXtYM2sBT.WaTt/QAcEQ/scRb8NmIOliD0/2UBZCu', 'admin', '2026-07-14 22:53:25'),
(4, 'Adam Bachtiar', 'adambachtiar1@gmail.com', '082124287328', 'Jl. Radin Inten II no. 54 B, Duren Sawit, Jakarta Timur', 'adam', '$2y$10$V3TYtf8z2mssoS2HMME5HuisaGwntV0EQp05k6WVIz2aSO3/z6AjS', 'user', '2026-07-14 22:53:25'),
(5, 'Abdullah Uways', 'abdul@cobacoba.com', '081234567899', 'Jalan Alun Alun Selatan, no, 12, SukmaJaya', 'abdul', '$2y$10$bqOws974BM9tH0BqPWo21uWaaRWEc18xvGuBPndtvKx8CtrKNAl12', 'user', '2026-07-17 03:24:14');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `kategori`
--
ALTER TABLE `kategori`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `konfigurasi`
--
ALTER TABLE `konfigurasi`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_konfigurasi_user` (`user_id`);

--
-- Indexes for table `konfigurasi_detail`
--
ALTER TABLE `konfigurasi_detail`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_detail_konfigurasi` (`konfigurasi_id`),
  ADD KEY `fk_detail_produk` (`produk_id`);

--
-- Indexes for table `produk`
--
ALTER TABLE `produk`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `kode_produk` (`kode_produk`),
  ADD KEY `fk_produk_kategori` (`kategori_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `unique_email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `kategori`
--
ALTER TABLE `kategori`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `konfigurasi`
--
ALTER TABLE `konfigurasi`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `konfigurasi_detail`
--
ALTER TABLE `konfigurasi_detail`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=39;

--
-- AUTO_INCREMENT for table `produk`
--
ALTER TABLE `produk`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `konfigurasi`
--
ALTER TABLE `konfigurasi`
  ADD CONSTRAINT `fk_konfigurasi_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON UPDATE CASCADE;

--
-- Constraints for table `konfigurasi_detail`
--
ALTER TABLE `konfigurasi_detail`
  ADD CONSTRAINT `fk_detail_konfigurasi` FOREIGN KEY (`konfigurasi_id`) REFERENCES `konfigurasi` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_detail_produk` FOREIGN KEY (`produk_id`) REFERENCES `produk` (`id`) ON UPDATE CASCADE;

--
-- Constraints for table `produk`
--
ALTER TABLE `produk`
  ADD CONSTRAINT `fk_produk_kategori` FOREIGN KEY (`kategori_id`) REFERENCES `kategori` (`id`) ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
